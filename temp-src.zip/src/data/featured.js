// Put poster images (or short mp4s) in /public/posters/ and /public/trailers/
import { Download } from "lucide-react";
import Slide1 from "../assets/project-icons/project/Slide1.png";
import Slide2 from "../assets/project-icons/project/Slide2.png";
import Slide3 from "../assets/project-icons/project/Slide3.png";
import Slide4 from "../assets/project-icons/project/Slide4.png";
export const FEATURED = [
    {
        id: "me",
        title: "Who Am I?",
        summary: "*Quick one-liner about me*",
        poster: Slide1,
        cta: { play: "#about", more: "/IshikaKhokhani_Resume.pdf" }
    },
    {
        id: "research",
        title: "Unveling Chess Algorithms using Reinforcement Learning",
        summary: "A comprehensive study on chess algorithms, comparing reinforcement learning with traditional methods.",
        poster: Slide3,
        cta: {
            play: { href: "/ChessAlgo.pdf", download: "/ChessAlgo.pdf" },
            more: "#research"
        }
    },
    {
        id: "intent",
        title: "Intent Classification - Banking Queries",
        summary: "Lightweight NLP pipeline with evaluation harness and fast inference.",
        poster: Slide2,
        cta: { play: "#", more: "#projects" }
    },
    {
        id: "buyme",
        title: "Buy-Me Shopping App",
        summary: "A shopping app with a user-friendly interface and secure payment options.",
        poster: Slide3,
        cta: { play: "#", more: "#projects" }
    },
    {
        id: "food",
        title: "Food Delivery App",
        summary: "App for food delivery with real-time tracking and user-friendly interface.",
        poster: Slide4,
        cta: { play: "#", more: "#projects" }
    }
];
