import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Play, Info } from "lucide-react";

export default function HeroSlider({
  items = [],
  interval = 6000,
  onPlay = () => {},
  onMore = () => {},
}) {
  const [index, setIndex] = useState(0);
  const [hover, setHover] = useState(false);
  const reduceMotion = useMemo(
    () => typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches,
    []
  );
  const count = items.length;
  const active = items[index] || {};

  // autoplay
  useEffect(() => {
    if (reduceMotion || hover || count <= 1) return;
    const id = setInterval(() => setIndex((i) => (i + 1) % count), interval);
    return () => clearInterval(id);
  }, [hover, count, interval, reduceMotion]);

  const go = (n) => setIndex((n + count) % count);
  const next = () => go(index + 1);
  const prev = () => go(index - 1);

  // keyboard support
  const wrapRef = useRef(null);
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const onKey = (e) => {
      if (e.key === "ArrowRight") next();
      if (e.key === "ArrowLeft") prev();
    };
    el.addEventListener("keydown", onKey);
    return () => el.removeEventListener("keydown", onKey);
  }, [index]);

  return (
    <section
      id="featured"
      ref={wrapRef}
      tabIndex={0}
      role="region"
      aria-label="Featured slideshow"
      className="relative h-[70vh] min-h-[28rem] w-full overflow-hidden outline-none"
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      {/* Background media */}
      {active.trailer ? (
        <video
          key={active.id + "-video"}
          className="absolute inset-0 h-full w-full object-cover"
          src={active.trailer}
          autoPlay
          muted
          loop
          playsInline
          preload="metadata"
        />
      ) : (
        <img
          key={active.id + "-img"}
          className="absolute inset-0 h-full w-full object-cover"
          src={active.poster}
          alt=""
          loading="eager"
        />
      )}

      {/* Top dark gradient (keeps nav readable) */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-black/70 via-black/30 to-transparent" />
      {/* Bottom fade to black (blend into page) */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-black" />

      {/* Content */}
      <div className="relative z-10 mx-auto flex h-full max-w-6xl items-end p-6">
        <div className="max-w-xl">
          <h1 className="mb-2 text-3xl font-bold drop-shadow">{active.title}</h1>
          <p className="mb-4 text-white/90 font-style: italic">{active.summary}</p>
          <div className="flex gap-3">
            <button
              onClick={() => onPlay(active)}
              className="inline-flex items-center gap-2 rounded-md bg-white px-4 py-2 text-sm font-semibold text-neutral-900"
            >
              <Play size={16} /> Play
            </button>
            <button
              onClick={() => onMore(active)}
              className="inline-flex items-center gap-2 rounded-md bg-white/20 px-4 py-2 text-sm font-semibold text-black/80 ring-1 ring-white/25 hover:bg-white/25"
            >
              <Info size={16} /> More Info
            </button>
          </div>
        </div>
      </div>

      {/* Controls */}
      {count > 1 && (
        <>
          <button
            aria-label="Previous"
            onClick={prev}
            className="absolute left-2 top-1/2 z-10 -translate-y-1/2 rounded-full bg-black/40 p-2 ring-1 ring-black/20 hover:bg-black/60"
          >
            <ChevronLeft className="text-black" />
          </button>
          <button
            aria-label="Next"
            onClick={next}
            className="absolute right-2 top-1/2 z-10 -translate-y-1/2 rounded-full bg-black/40 p-2 ring-1 ring-black/20 hover:bg-black/60"
          >
            <ChevronRight className="text-black"/>
          </button>

          {/* Dots */}
          <div className="absolute bottom-4 left-1/2 z-10 -translate-x-1/2 h-2 w-2">
            <div className="flex gap-2">
              {items.map((it, i) => (
                <button
                  key={it.id}
                  aria-label={`Go to slide ${i + 1}`}
                  onClick={() => go(i)}
                  className={`h-0.5 w-0.5 rounded-full transition  ${
                    i === index ? "!bg-white scale-75" : "!bg-white/40 scale-50 hover:bg-white/70"
                  }`}
                />
              ))}
            </div>
          </div>
        </>
      )}
    </section>
  );
}
