import { useEffect, useRef, useState } from "react";
import { User, ChevronDown, GraduationCap, Github, Linkedin, Mail, Download, User2 } from "lucide-react";


export default function AboutMenu({ onNavigate }) {
  const [open, setOpen] = useState(false);
  const btnRef = useRef(null);
  const menuRef = useRef(null);

  // close on outside click / Esc
  useEffect(() => {
    const onClick = (e) => {
      if (!open) return;
      if (!menuRef.current || !btnRef.current) return;
      if (!menuRef.current.contains(e.target) && !btnRef.current.contains(e.target)) setOpen(false);
    };
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    window.addEventListener("mousedown", onClick);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("mousedown", onClick);
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  useEffect(() => {
    if (open) {
      // focus first item for accessibility
      const first = menuRef.current?.querySelector("a, button");
      first?.focus();
    }
  }, [open]);

  const items = [
    // { label: "Education", href: "#education", Icon: GraduationCap },
    { label: "GitHub", href: "https://github.com/ishikakhokhani", Icon: Github, external: true },
    { label: "LinkedIn", href: "https://www.linkedin.com/in/ishikakhokhani", Icon: Linkedin, external: true },
    { label: "Email", href: "mailto:ishikarkhokhani@gmail.com", Icon: Mail },
    { label: "Download Resume", href: "/IshikaKhokhani_Resume.pdf", Icon: Download, download: "IshikaKhokhani_Resume.pdf" },
  ];

  return (
    <div className="relative">
      <button
        ref={btnRef}
        onClick={() => setOpen((v) => !v)}
        className="inline-flex items-center gap-1 rounded-full px-3 py-1 text-sm !bg-transparent text-white/80 hover:bg-white/15 focus:outline-none focus:ring-2 !focus:ring-white/50"
        aria-haspopup="menu"
        aria-expanded={open}
      >
        <User2 size={16} /> About Me <ChevronDown size={14} className={`transition ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <div
          ref={menuRef}
          role="menu"
          className="absolute left-0 right-0 top-full mt-3.5 w-72 rounded !bg-black/20 backdrop-blur p-1  shadow-lg z-50"
        >
           <a
      href="#/education"
      role="menuitem"
      className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm !text-white/85 hover:bg-white/10 focus:bg-white/10 focus:outline-none"
      onClick={(e) => {
        e.preventDefault();
        // Prefer calling App's goto() if provided; otherwise just set the hash
        onNavigate ? onNavigate("#/education") : (window.location.hash = "#/education");
        setOpen(false);
      }}
    >
      <GraduationCap size={16} /> <span>Education</span>
    </a>
          {items.map(({ label, href, Icon, external, download }) => (
            <a
              key={label}
              href={href}
              {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
              {...(download ? { download } : {})}
              role="menuitem"
              className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm !text-white/85 hover:bg-white/10 focus:bg-white/10 focus:outline-none"
              onClick={() => setOpen(false)}
            >
              <Icon size={16} /> <span>{label}</span>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}
