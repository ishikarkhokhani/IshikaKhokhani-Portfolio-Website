import { useEffect, useRef, useState } from "react";
import { User, ChevronDown, Download, SignatureIcon, Banknote, ShoppingBagIcon, Pizza, Pencil, ComputerIcon, User2Icon, ArrowBigUp, PersonStandingIcon, Worm, WavesLadder, FishIcon, BookCheck, BookA, BookAlert, BookCopy, Webhook, WebhookOffIcon, WebcamIcon, SproutIcon, SparkleIcon, PaintbrushVerticalIcon, SwatchBook, ZapIcon, BanIcon, PiIcon, CogIcon, TagIcon, BugIcon } from "lucide-react";
import { spring } from "framer-motion";

export default function AboutMenu() {
  const [open, setOpen] = useState(false);
  const btnRef = useRef(null);
  const menuRef = useRef(null);

  // close on outside click / Esc
  useEffect(() => {
    const onClick = (e) => {
      if (!open) return;
      if (!menuRef.current || !btnRef.current) return;
      if (!menuRef.current.contains(e.target) && !btnRef.current.contains(e.target)) setOpen(false);
    };
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    window.addEventListener("mousedown", onClick);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("mousedown", onClick);
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  useEffect(() => {
    if (open) {
      // focus first item for accessibility
      const first = menuRef.current?.querySelector("a, button");
      first?.focus();
    }
  }, [open]);

  const items = [
    { label: "IEEE Publication", href: "#ieee", Icon: SwatchBook },
    { label: "Springer Publication", href: "#startup", Icon: SproutIcon },
    { label: "Other", href: "#otherpub", Icon: BugIcon },
  ];

  return (
    <div className="relative">
      <button
        ref={btnRef}
        onClick={() => setOpen((v) => !v)}
        className="inline-flex items-center gap-1 rounded-full px-3 py-1 text-sm !bg-transparent text-white/80 hover:bg-white/15 focus:outline-none focus:ring-2 !focus:ring-white/50"
        aria-haspopup="menu"
        aria-expanded={open}
      >
        <BookCopy size={16} /> Research <ChevronDown size={14} className={`transition ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <div
          ref={menuRef}
          role="menu"
          className="absolute left-2.5 right-0 top-full mt-3.5 w-50 rounded !bg-black/20 backdrop-blur p-1  shadow-lg z-50"
        >
          {items.map(({ label, href, Icon, external, download }) => (
            <a
              key={label}
              href={href}
              {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
              {...(download ? { download } : {})}
              role="menuitem"
              className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm !text-white/85 hover:bg-white/10 focus:bg-white/10 focus:outline-none"
              onClick={() => setOpen(false)}
            >
              <Icon size={16} /> <span>{label}</span>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}
