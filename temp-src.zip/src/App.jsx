import React, { useMemo, useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Logo from "./assets/logo-name.png";
import HeroSlider from "./components/HeroSlider.jsx";
import AboutMenu from "./components/AboutMenu.jsx";
import ProjectMenu from "./components/ProjectMenu.jsx";
import WorkMenu from "./components/WorkMenu.jsx";
import ResearchMenu from "./components/ResearchMenu.jsx";
import EducationPage from "./pages/EducationPage.jsx";
import SkillsMenu from "./components/SkillsMenu.jsx";
import { FEATURED } from "./data/featured.js";
import { GraduationCap, MapPin, BookOpen, ChevronDown, ChevronUp } from "lucide-react";

import { Github, Linkedin, Mail, Download, ExternalLink, X, Play, Search, Info, BadgeInfo, InfoIcon, PersonStanding, PersonStandingIcon, User, Computer, BaggageClaim, Workflow, Book, Laptop, ComputerIcon, BookCopy, Pencil, School, School2 } from "lucide-react";

// --- Data -------------------------------------------------------------
const PROFILES = [
  {
    id: "se",
    title: "Ishika — Software Engineer",
    tagline: "Builds reliable systems, ships clean code, loves performance.",
  },
  {
    id: "da",
    title: "Ishika — Data Analyst",
    tagline: "Turns messy data into clear stories and business impact.",
  },
];

const TAGS = {
  python: { label: "Python" },
  js: { label: "JavaScript" },
  react: { label: "React" },
  next: { label: "Next.js" },
  kafka: { label: "Kafka" },
  aws: { label: "AWS" },
  sql: { label: "SQL" },
  sklearn: { label: "scikit-learn" },
  flutter: { label: "Flutter" },
  firebase: { label: "Firebase" },
  tableau: { label: "Tableau" },
};

// Each item mimics a Netflix title "poster"
const CATEGORIES = [
  {
    id: "experience",
    title: "Work Experience Originals",
    items: [
      {
        id: "blockhouse-sor",
        title: "Smart Order Router",
        subtitle: "Blockhouse Quant Trial",
        year: "2024–2025",
        summary:
          "Backtested and benchmarked a smart order router using the Cont and Kukanov model with Kafka based market sim and AWS EC2 deployment.",
        bullets: [
          "Designed Python pipelines to replay order book events",
          "Compared execution strategies, reduced slippage variance",
          "Automated experiments and reports",
        ],
        tags: ["python", "kafka", "aws", "sql"],
        links: [
          { label: "Writeup", href: "#" },
          { label: "Code", href: "#" },
        ],
        color: "from-blue-500 via-sky-500 to-cyan-400",
      },
      {
        id: "soul9-data",
        title: "Growth Analytics Platform",
        subtitle: "Soul9, Co‑Founder and Data Engineer",
        year: "2022–2024",
        summary:
          "Built Python based ETL and forecasting that processed 1000+ weekly transactions, improved decisions, and increased revenue by 18 percent.",
        bullets: [
          "Automated ETL and reporting, forty percent less manual work",
          "Deployed forecasting models with scikit learn",
          "Delivered dashboards for non technical teams",
        ],
        tags: ["python", "sklearn", "sql", "tableau"],
        links: [{ label: "Case study", href: "#" }],
        color: "from-fuchsia-500 via-pink-500 to-rose-400",
      },
      {
        id: "nirvana-swe",
        title: "Operational Tracking System",
        subtitle: "Nirvana Furnishings, SWE Intern",
        year: "2021–2024",
        summary:
          "Real time tracking with Python and JS, plus analytics dashboards that improved throughput by twenty percent across departments.",
        bullets: [
          "Built REST services and SQL models",
          "Rolled out UI and trained teams",
          "Wrote clear documentation",
        ],
        tags: ["python", "js", "sql"],
        links: [{ label: "Overview", href: "#" }],
        color: "from-amber-500 via-orange-500 to-red-400",
      },
    ],
  },
  {
    id: "projects",
    title: "Projects You May Like",
    items: [
      {
        id: "buyme",
        title: "Buy Me Shopping App",
        subtitle: "Cross platform app",
        year: "2023",
        summary:
          "Flutter plus Firebase shopping app with provider pattern and Material Design, clean auth and cart flows.",
        bullets: [
          "Cross platform iOS and Android",
          "Realtime database and auth",
          "Modular state management",
        ],
        tags: ["flutter", "firebase"],
        links: [{ label: "Demo", href: "#" }],
        color: "from-emerald-500 via-green-500 to-lime-400",
      },
      {
        id: "intent-nlp",
        title: "Intent Classifier",
        subtitle: "NLP pipeline",
        year: "2024",
        summary:
          "Built a lightweight intent classification pipeline and evaluation harness for support messages.",
        bullets: [
          "Data cleaning and labeling",
          "Model comparison and error analysis",
          "FastAPI inference service",
        ],
        tags: ["python", "sklearn"],
        links: [{ label: "Repo", href: "#" }],
        color: "from-indigo-500 via-violet-500 to-purple-400",
      },
      {
        id: "viz-biblio",
        title: "Bibliometric Visualizer",
        subtitle: "Research impact",
        year: "2025",
        summary:
          "Interactive visuals for citations and co authorship with VOSviewer exports and custom charts.",
        bullets: [
          "Designed data model",
          "Built filters and drilldowns",
          "Clear insight narratives",
        ],
        tags: ["react", "js"],
        links: [{ label: "Live", href: "#" }],
        color: "from-cyan-500 via-teal-500 to-emerald-400",
      },
    ],
  },
  {
    id: "skills",
    title: "Skills and Technologies",
    items: [
      { id: "python", title: "Python", summary: "Daily driver for data and backend.", tags: ["python"], color: "from-sky-600 via-blue-600 to-indigo-600" },
      { id: "react", title: "React", summary: "Interactive UIs and dashboards.", tags: ["react", "js"], color: "from-neutral-600 via-slate-600 to-zinc-600" },
      { id: "sql", title: "SQL", summary: "Analytics and modeling.", tags: ["sql"], color: "from-stone-600 via-gray-600 to-neutral-600" },
      { id: "aws", title: "AWS", summary: "EC2, S3, CI and deploys.", tags: ["aws"], color: "from-yellow-600 via-amber-600 to-orange-600" },
      { id: "kafka", title: "Kafka", summary: "Streaming and simulation.", tags: ["kafka"], color: "from-rose-600 via-red-600 to-orange-600" },
    ],
  },
  {
    id: "awards",
    title: "Trending Now, Awards and Milestones",
    items: [
      { id: "award1", title: "Dean List VT", summary: "Academic recognition.", year: "2025", color: "from-teal-500 via-emerald-500 to-green-400" },
      { id: "award2", title: "Hackathon Finalist", summary: "Prototype in 24 hours.", year: "2024", color: "from-blue-700 via-indigo-700 to-violet-700" },
    ],
  },
];

// --- UI helpers -------------------------------------------------------
function Tag({ id }) {
  const t = TAGS[id] || { label: id };
  return (
    <span className="mr-1 mb-1 inline-flex rounded-full bg-white/10 px-2 py-0.5 text-xs text-white/90 ring-1 ring-white/10">
      {t.label}
    </span>
  );
}

function Poster({ item, onOpen }) {
  return (
    <motion.button
      whileHover={{ scale: 1.03 }}
      whileFocus={{ scale: 1.02 }}
      className="group relative h-44 w-72 flex-shrink-0 overflow-hidden rounded-2xl bg-gradient-to-br p-0 text-left shadow-lg"
      onClick={() => onOpen(item)}
      style={{ WebkitMaskImage: "-webkit-radial-gradient(white, black)" }}
    >
      <div className={`absolute inset-0 bg-gradient-to-br ${item.color}`} />
      <div className="absolute inset-0 bg-black/30" />
      <div className="absolute inset-0 flex flex-col justify-end p-4">
        <div className="text-lg font-semibold text-white drop-shadow-sm">{item.title}</div>
        <div className="text-xs text-white/80">{item.subtitle}</div>
        <div className="mt-2 flex flex-wrap">
          {(item.tags || []).slice(0, 4).map((t) => (
            <Tag key={t} id={t} />
          ))}
        </div>
      </div>
      <div className="absolute right-3 top-3 hidden items-center gap-1 rounded-full bg-white/10 px-2 py-1 text-xs text-white/90 ring-1 ring-white/10 group-hover:flex">
        <Play size={14} />
        <span>Open</span>
      </div>
    </motion.button>
  );
}

function Row({ title, items, onOpen }) {
  return (
    <section className="mb-8">
      <h2 className="mb-3 px-2 text-lg font-semibold text-white/95">{title}</h2>
      <div className="no-scrollbar flex gap-4 overflow-x-auto px-2 pb-1">
        {items.map((it) => (
          <Poster key={it.id} item={it} onOpen={onOpen} />
        ))}
      </div>
    </section>
  );
}

function Modal({ item, onClose }) {
  if (!item) return null;
  return (
    <AnimatePresence>
      {item && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
        >
          <motion.div
            initial={{ scale: 0.96, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.98, opacity: 0 }}
            className="w-full max-w-3xl overflow-hidden rounded-3xl bg-neutral-900 ring-1 ring-white/10"
          >
            <div className={`h-40 w-full bg-gradient-to-br ${item.color} relative`}>
              <button
                onClick={onClose}
                className="absolute right-3 top-3 rounded-full bg-black/50 p-2 text-white hover:bg-black/60"
                aria-label="Close"
              >
                <X size={18} />
              </button>
            </div>
            <div className="space-y-3 p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="text-xl font-semibold text-white">{item.title}</h3>
                  <p className="text-sm text-white/70">{item.subtitle} · {item.year}</p>
                </div>
                <div className="flex items-center gap-2">
                  {(item.links || []).map((l) => (
                    <a
                      key={l.label}
                      href={l.href}
                      className="inline-flex items-center gap-1 rounded-full bg-white/10 px-3 py-1 text-sm text-white ring-1 ring-white/15 hover:bg-white/15"
                    >
                      <ExternalLink size={14} /> {l.label}
                    </a>
                  ))}
                </div>
              </div>
              <p className="text-white/90">{item.summary}</p>
              <ul className="list-disc space-y-1 pl-5 text-white/90">
                {(item.bullets || []).map((b, i) => (
                  <li key={i}>{b}</li>
                ))}
              </ul>
              <div className="pt-1">
                {(item.tags || []).map((t) => (
                  <Tag key={t} id={t} />
                ))}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function Profiles({ onChoose }) {
  return (
    <div className="flex min-h-[100vh] items-center justify-center">
      <div className="mx-auto w-full max-w-3xl text-center">
        <h1 className="mb-2 text-3xl font-bold text-white">What have I done?</h1>
        <p className="mb-8 text-white/70">Pick a section to explore on the portfolio.</p>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          {PROFILES.map((p) => (
            <button
              key={p.id}
              onClick={() => onChoose(p)}
              className="group overflow-hidden rounded-3xl bg-neutral-800 p-6 text-left ring-1 ring-white/10 transition hover:bg-neutral-700"
            >
              <div className="mb-4 h-28 w-full rounded-2xl bg-gradient-to-br from-red-500 via-rose-500 to-pink-400" />
              <div className="text-white">
                <div className="text-lg font-semibold group-hover:underline text-black/70">{p.title}</div>
                <div className="text-sm text-black/70">{p.tagline}</div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// --- Main App ---------------------------------------------------------
export default function App() {
  const [profile, setProfile] = useState(null);
  const [active, setActive] = useState(null);
  const [query, setQuery] = useState("");

  const [route, setRoute] = useState(window.location.hash || "#/");

  const goto = (hash) => {
    if (window.location.hash !== hash) {
      window.location.hash = hash;  // updates address bar + history
    }
    setRoute(hash);                 // updates React state (no event listener needed)
  };


  useEffect(() => {
    const onHash = () => setRoute(window.location.hash || "#/");
    window.addEventListener("hashchange", onHash);
    onHash(); 
    return () => window.removeEventListener("hashchange", onHash);
  }, []);


  const isHome = route === "#/" || route === "" || route === "#";
  const isEducation = route === "#/education";

  const filtered = useMemo(() => {
    if (!query) return CATEGORIES;
    const q = query.toLowerCase();
    return CATEGORIES.map((c) => ({
      ...c,
      items: c.items.filter((it) =>
        [it.title, it.subtitle, it.summary, ...(it.tags || [])]
          .join(" ")
          .toLowerCase()
          .includes(q)
      ),
    })).filter((c) => c.items.length > 0);
  }, [query]);

  const featured = CATEGORIES[0].items[0];
  const onPlay = (item) => setActive(item);            
  const onMore = (item) => setActive(item);            

  return (
    <div className="bg-neutral-950 text-white">

      <header className="fixed inset-x-0 top-0 z-50 bg-transparent backdrop-blur-sm">
        <div className="mx-12 flex max-w-8xl items-center gap-3 px-0 py-3">
          {/* Left: logo */}
          <div className="flex items-center gap-2">
            <a href="#" aria-label="Go home" className="inline-flex items-center">
              <img src={Logo} alt="IK Logo" className="h-12 w-auto" />
            </a>
          </div>

          {/* Right: actions */}
          {/* <div className="ml-auto flex items-center gap-2">
            <a href="#"
              className="inline-flex items-center gap-1 rounded-full px-3 py-1 text-sm !text-white/80 hover:bg-white/15"
              target="_blank" rel="noopener noreferrer">
              <User size={16} /> About Me
            </a> */}

          <div className="ml-auto flex items-center gap-1">
            {/* About Me - dropdown menu */}
            <AboutMenu onNavigate={goto} />
            <SkillsMenu />
            <ProjectMenu />
            <WorkMenu />
            <ResearchMenu />



            {/* <a href="#"
              className="inline-flex items-center gap-1 rounded-full px-3 py-1 text-sm !text-white/80 hover:bg-white/15"
              target="_blank" rel="noopener noreferrer">
              <Pencil size={16} /> Projects
            </a> */}

            {/* // <a href="#"
            //   className="inline-flex items-center gap-1 rounded-full px-3 py-1 text-sm !text-white/80 hover:bg-white/15"
            //   target="_blank" rel="noopener noreferrer">
            //   <ComputerIcon size={16} /> Work Experience
            // </a> */}

            {/* <a href="#"
              className="inline-flex items-center gap-1 rounded-full px-3 py-1 text-sm !text-white/80 hover:bg-white/15"
              target="_blank" rel="noopener noreferrer">
              <BookCopy size={16} /> Research Papers
            </a> */}
            {/* <a href="#"
              className="inline-flex items-center gap-1 rounded-full px-3 py-1 text-sm !text-white/80 hover:bg-white/15"
              target="_blank" rel="noopener noreferrer">
              <School2 size={16} /> Education
            </a>
            <a href="https://github.com/ishikakhokhani"
              className="inline-flex items-center gap-1 rounded-full px-3 py-1 text-sm !text-white/80 hover:bg-white/15"
              target="_blank" rel="noopener noreferrer">
              <Github size={16} /> GitHub
            </a>
            <a href="https://www.linkedin.com/in/ishikakhokhani"
              className="inline-flex items-center gap-1 rounded-full px-3 py-1 text-sm !text-white/80 hover:bg-white/15"
              target="_blank" rel="noopener noreferrer">
              <Linkedin size={16} /> LinkedIn
            </a>
            <a href="mailto:ishikarkhokhani@gmail.com"
              className="inline-flex items-center gap-1 rounded-full px-3 py-1 text-sm !text-white/80 hover:bg-white/15">
              <Mail size={16} /> Email
            </a>
            <a href="/IshikaKhokhani_Resume.pdf"
              download="IshikaKhokhani_Resume.pdf"
              aria-label="Download Resume"
              className="inline-flex items-center gap-1 rounded-full px-3 py-1 text-sm !text-white/80 hover:bg-white/15"
              target="_blank" rel="noopener noreferrer">
              <Download size={16} /> Resume
            </a> */}
          </div>

          {/* Search */}
          <div className="relative hidden w-20 items-center sm:flex -translate-x-3.5">
            <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-2 text-white/50" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search"
              className="w-30 rounded-2xl border border-white/10 bg-white/5 px-7.5 py-2 text-sm outline-none placeholder:text-white/40 focus:ring-2 focus:ring-red-500/50"
            />
          </div>
        </div>
      </header>

      {isEducation ? (
        <EducationPage onNavigate={goto}/>
      ) : (
        <>
          {/* Hero spacer under the fixed header */}
          <section className="relative h-56 w-full overflow-hidden">
            <div className="absolute inset-0 bg-transparent" />
          </section>

          {/* Profile gate */}
          {!profile && (
            <main className="mx-auto max-w-6xl px-4">
              <Profiles onChoose={setProfile} />
            </main>
          )}

          {/* Content once a profile is chosen */}
          {profile && (
            <>
              {/* Hero card */}
              <section className="relative mx-auto mb-8 max-w-6xl overflow-hidden rounded-3xl border border-white/10 bg-neutral-900">
                <div className={`h-64 w-full bg-gradient-to-br ${featured.color} relative`}>
                  <div className="absolute inset-0 bg-black/30" />
                  <div className="absolute inset-0 flex flex-col justify-end p-6">
                    <div className="mb-2 inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs ring-1 ring-white/15">
                      <span className="text-white/90">Featured</span>
                    </div>
                    <h1 className="text-2xl font-bold text-white drop-shadow">{featured.title}</h1>
                    <p className="max-w-2xl text-white/90">{featured.summary}</p>
                    <div className="mt-3 flex items-center gap-2">
                      <a href="#" className="inline-flex items-center gap-2 rounded-md bg-white px-4 py-2 text-sm font-semibold text-neutral-900">
                        <Play size={16} /> Open details
                      </a>
                      <button className="inline-flex items-center gap-2 rounded-md bg-white/10 px-4 py-2 text-sm font-semibold text-white ring-1 ring-white/15">
                        Save for later
                      </button>
                    </div>
                  </div>
                </div>
              </section>

              {/* Rows */}
              <main className="mx-auto max-w-6xl px-2">
                {filtered.map((cat) => (
                  <Row key={cat.id} title={cat.title} items={cat.items} onOpen={setActive} />
                ))}
              </main>

              {/* Footer */}
              <footer className="mx-auto mt-10 max-w-6xl px-4 pb-10 text-center text-sm text-white/50">
                Built with React, Tailwind, and Framer Motion. Deployed on Vercel.
              </footer>

              {/* Modal */}
              <Modal item={active} onClose={() => setActive(null)} />
            </>
          )}
        </>
      )}



      {/* <img src={'https://occ-0-2433-2430.1.nflxso.net/dnm/api/v6/6AYY37jfdO6hpXcMjf9Yu5cnmO0/AAAABWkkMmZlG1Cy4rkWVifAn8t-Bd8QBeKTJlnOlgKbRgtzKU4beqENTuPlJrHWNPTLMvMgB1iYwXBTNbMR_v87guu1FePmwoegYagy.webp?r=79b'} alt="IK Logo" className=" mx-auto h-auto w-full" /> */}
    </div>
  );
}




// --- Styles used inside this file ------------------------------------
// Utility class to hide scrollbars without removing scroll behavior
const styles = `
  .no-scrollbar::-webkit-scrollbar { display: none; }
  .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
`;

if (typeof document !== "undefined") {
  const styleTag = document.createElement("style");
  styleTag.innerHTML = styles;
  document.head.appendChild(styleTag);
}
