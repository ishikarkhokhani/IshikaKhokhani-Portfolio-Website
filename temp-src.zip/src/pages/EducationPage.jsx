import { useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { ChevronDown, ChevronUp } from "lucide-react";


import {
  GraduationCap,
  Award,
  BookOpen,
  Trophy,
  ExternalLink,
  X,
  MapPin,
} from "lucide-react";

export default function EducationPage({ onNavigate }) {
  const [active, setActive] = useState(null);

  const MS_COURSES = [
    {
      id: "ml",
      title: "Machine Learning",
      where: "Virginia Tech",
      when: "Fall 2024",
      color: "from-teal-700 via-cyan-700 to-sky-600",
      summary:
        "Supervised & unsupervised methods: logistic regression, decision trees, SVMs, clustering; intro neural nets; feature engineering & evaluation.",
      tags: ["scikit-learn", "Pandas", "NumPy", "SVM", "Decision Trees"],
      links: [{ label: "Projects", href: "#" }],
    },
    {
      id: "cn",
      title: "Network Security",
      where: "Virginia Tech",
      when: "Fall 2024",
      color: "from-rose-700 via-red-700 to-rose-600",
      summary:
        "Crypto basics, authentication, TLS/SSL & PKI, firewalls, IDS/IPS, VPNs; email and wireless security.",
      tags: ["TLS/SSL", "PKI", "IDS/IPS", "Firewalls"],
      links: [{ label: "Notes", href: "#" }],
    },
    {
      id: "ai",
      title: "Introduction to Artificial Intelligence",
      where: "Virginia Tech",
      when: "Fall 2024",
      color: "from-indigo-700 via-blue-700 to-sky-600",
      summary:
        "State-space search, game playing (Pac-Man agents), CSPs, logic & reasoning, planning, intro ML and multi-agent systems.",
      tags: ["Search", "CSP", "Planning", "Logic"],
      links: [{ label: "Notes", href: "#" }],
    },
    {
      id: "nlp",
      title: "Natural Language Processing",
      where: "Virginia Tech",
      when: "Spring 2025",
      color: "from-amber-700 via-orange-700 to-red-600",
      summary:
        "Text classification and tokenization, TF-IDF, sequence models and transformers (BERT); POS tagging and NER.",
      tags: ["Transformers", "BERT", "TF-IDF", "PyTorch"],
      links: [{ label: "Project", href: "#" }],
    },
    {
      id: "clp",
      title: "Cloud Computing",
      where: "Virginia Tech",
      when: "Spring 2025",
      color: "from-slate-800 via-gray-400 to-zinc-800",
      summary:
        "Cloud architectures, AWS services, containerization with Docker/Kubernetes, microservices, and serverless patterns.",
      tags: ["AWS", "Docker", "Kubernetes", "Serverless"],
      links: [{ label: "Project", href: "#" }],
    },
    {
      id: "mob",
      title: "Mobile App Development",
      where: "Virginia Tech",
      when: "Spring 2025",
      color: "from-fuchsia-700 via-purple-700 to-violet-700",
      summary:
        "Android/iOS development with Flutter/React Native; mobile UX patterns, native APIs, and deployment pipelines.",
      tags: ["Flutter", "React Native", "Android", "iOS"],
      links: [{ label: "Project", href: "#" }],
    },
    {
      id: "dl",
      title: "Introduction to Deep Learning",
      where: "Virginia Tech",
      when: "Fall 2025",
      color: "from-rose-800 via-pink-700 to-fuchsia-700",
      summary:
        "Neural networks from scratch; CNNs, RNN/LSTM; autoencoders & GANs; transfer learning and hyperparameter tuning.",
      tags: ["PyTorch", "CNNs", "RNNs", "GANs"],
      links: [{ label: "Project", href: "#" }],
    },
    {
      id: "se",
      title: "Software Engineering",
      where: "Virginia Tech",
      when: "Fall 2025",
      color: "from-emerald-700 via-green-700 to-teal-700",
      summary:
        "Agile and DevOps practices; CI/CD, testing strategies, design patterns, microservices, and API design.",
      tags: ["Agile", "CI/CD", "Testing", "Design Patterns"],
      links: [{ label: "Project", href: "#" }],
    },
    {
      id: "ait",
      title: "AI Tools for Software Engineering",
      where: "Virginia Tech",
      when: "Fall 2025",
      color: "from-purple-800 via-rose-700 to-red-700",
      summary:
        "Using LLMs for code generation & review, automated bug detection, and AI-assisted DevOps workflows.",
      tags: ["LLMs", "CodeGen", "Static Analysis", "DevOps"],
      links: [{ label: "Project", href: "#" }],
    },
    {
      id: "cp",
      title: "Capstone Project",
      where: "Virginia Tech",
      when: "Fall 2025",
      color: "from-cyan-800 via-teal-700 to-emerald-700",
      summary:
        "Team project applying AI/ML to a real problem; full lifecycle: scoping, builds, reviews, and presentation.",
      tags: ["Team", "ML", "Full-stack", "Presentation"],
      links: [{ label: "Project", href: "#" }],
    },
    {
      id: "eth",
      title: "Ethics and Professionalism in Computer Science",
      where: "Virginia Tech",
      when: "Spring 2026",
      color: "from-slate-700 via-gray-700 to-zinc-700",
      summary:
        "Ethics in computing and AI: privacy, fairness/bias, intellectual property, professional conduct, and social impact.",
      tags: ["Privacy", "IP", "Fairness", "Bias"],
      links: [{ label: "Notes", href: "#" }],
    },
  ];



  const UG_COURSES = [
    {
      id: "eng-mechanics",
      title: "Engineering Mechanics",
      where: "University of Mumbai",
      when: "Semester 1",
      color: "from-amber-900 via-orange-800 to-red-700",
      summary: "Statics, dynamics, forces, and motion; engineering problem-solving.",
      tags: ["Statics", "Dynamics", "FBD", "Moments", "Equilibrium", "Kinematics", "Kinetics"],
      links: [{ label: "Notes", href: "#" }],
    },
    {
      id: "eng-graphics",
      title: "Engineering Graphics",
      where: "University of Mumbai",
      when: "Semester 2",
      color: "from-emerald-800 via-green-700 to-teal-700",
      summary: "Projections, sections, dimensioning; visual communication for engineering.",
      tags: ["Orthographic", "Isometric", "Projections", "Sections", "Dimensioning", "CAD"],
      links: [{ label: "Notes", href: "#" }],
    },
    {
      id: "c-prog",
      title: "C Programming",
      where: "University of Mumbai",
      when: "Semester 2",
      color: "from-sky-800 via-blue-700 to-indigo-700",
      summary: "C syntax, pointers, memory, structs, and modular programming.",
      tags: ["C", "Pointers", "Arrays", "Structs", "Functions", "File I/O", "Memory Mgmt"],
      links: [{ label: "Lab", href: "#" }],
    },
    {
      id: "pce",
      title: "Professional Communication & Ethics",
      where: "University of Mumbai",
      when: "Semester 2",
      color: "from-rose-800 via-pink-700 to-fuchsia-700",
      summary: "Ethics, teamwork, presentations, and technical writing for engineers.",
      tags: ["Ethics", "Teamwork", "Technical Writing", "Presentations", "Professionalism", "Documentation"],
      links: [{ label: "Case Study", href: "#" }],
    },
    {
      id: "dsa",
      title: "Data Structure and Analysis",
      where: "University of Mumbai",
      when: "Semester 3",
      color: "from-emerald-800 via-green-700 to-teal-700",
      summary: "Arrays, trees, graphs, greedy/DP; complexity and implementation.",
      tags: ["Linked Lists", "Trees", "Graphs", "Sorting", "Greedy", "DP", "Complexity"],
      links: [{ label: "Lab", href: "#" }],
    },
    {
      id: "dbms",
      title: "Database Management System",
      where: "University of Mumbai",
      when: "Semester 3",
      color: "from-violet-800 via-purple-700 to-fuchsia-700",
      summary: "Relational design, SQL, normalization, transactions, indexing.",
      tags: ["SQL", "ER Modeling", "Normalization", "ACID", "Transactions", "Indexing"],
      links: [{ label: "Project", href: "#" }],
    },
    {
      id: "principles-comms",
      title: "Principle of Communication",
      where: "University of Mumbai",
      when: "Semester 3",
      color: "from-cyan-800 via-teal-700 to-emerald-700",
      summary: "Analog/digital modulation, noise, and basic communication systems.",
      tags: ["AM/FM", "PSK/QAM", "Sampling", "Bandwidth", "Noise", "Digital Comm"],
      links: [{ label: "Notes", href: "#" }],
    },
    {
      id: "paradigms",
      title: "Paradigms and Computer Programming Fundamentals",
      where: "University of Mumbai",
      when: "Semester 3",
      color: "from-amber-900 via-amber-700 to-orange-700",
      summary: "Imperative, OO, functional, and scripting approaches; Java focus.",
      tags: ["Imperative", "OOP", "Functional", "Scripting", "Java", "Python"],
      links: [{ label: "Lab", href: "#" }],
    },
    {
      id: "java-lab",
      title: "Java Lab",
      where: "University of Mumbai",
      when: "Semester 3",
      color: "from-slate-800 via-gray-700 to-zinc-700",
      summary: "OOP in Java, collections, GUI, and basic networking.",
      tags: ["Java", "OOP", "Collections", "Exceptions", "Threads", "GUI", "Networking"],
      links: [{ label: "Exercises", href: "#" }],
    },
    {
      id: "sql-lab",
      title: "SQL Lab",
      where: "University of Mumbai",
      when: "Semester 3",
      color: "from-amber-800 via-orange-700 to-red-700",
      summary: "Queries and tuning: joins, subqueries, constraints, views, procedures, indexing.",
      tags: ["DDL/DML", "Joins", "Subqueries", "Constraints", "Views", "Indexes", "Stored Procs"],
      links: [{ label: "Exercises", href: "#" }],
    },
    {
      id: "networks",
      title: "Computer Network And Network Design",
      where: "University of Mumbai",
      when: "Semester 4",
      color: "from-indigo-900 via-indigo-700 to-violet-700",
      summary: "TCP/IP stack, routing, DNS/HTTP, and network topology design.",
      tags: ["TCP/IP", "Subnetting", "Routing", "DNS", "HTTP", "Topology", "NAT/VLAN"],
      links: [{ label: "Lab", href: "#" }],
    },
    {
      id: "os",
      title: "Operating System",
      where: "University of Mumbai",
      when: "Semester 4",
      color: "from-teal-900 via-teal-700 to-emerald-700",
      summary: "Processes/threads, scheduling, memory, I/O, concurrency & deadlocks.",
      tags: ["Processes", "Threads", "Scheduling", "Synchronization", "Deadlocks", "Virtual Memory", "File Systems"],
      links: [{ label: "Notes", href: "#" }],
    },
    {
      id: "automata",
      title: "Automata Theory",
      where: "University of Mumbai",
      when: "Semester 4",
      color: "from-red-900 via-rose-700 to-pink-700",
      summary: "Finite automata, regular languages, CFGs, Turing machines, decidability.",
      tags: ["DFA/NFA", "Regex", "CFG", "PDA", "Turing Machines", "Decidability"],
      links: [{ label: "Notes", href: "#" }],
    },
    {
      id: "coa",
      title: "Computer Organization And Architecture",
      where: "University of Mumbai",
      when: "Semester 4",
      color: "from-green-900 via-emerald-700 to-teal-700",
      summary: "CPU design, instruction sets, pipelining, memory hierarchy.",
      tags: ["CPU", "ISA", "ALU", "Pipelining", "Cache", "Memory Hierarchy", "Microarchitecture"],
      links: [{ label: "Lab", href: "#" }],
    },
    {
      id: "unix",
      title: "Unix Programming",
      where: "University of Mumbai",
      when: "Semester 4",
      color: "from-amber-900 via-orange-800 to-red-700",
      summary: "Shell scripting, process management, file I/O, and system calls.",
      tags: ["Shell", "Bash", "Processes", "Signals", "System Calls", "File I/O", "IPC"],
      links: [{ label: "Notes", href: "#" }],
    },
    {
      id: "internet-prog",
      title: "Internet Programming",
      where: "University of Mumbai",
      when: "Semester 5",
      color: "from-sky-900 via-sky-700 to-cyan-700",
      summary: "Web foundations: HTML/CSS/JS, client–server patterns, basics of APIs.",
      tags: ["HTML", "CSS", "JavaScript", "HTTP", "REST", "AJAX", "Sessions/Cookies"],
      links: [{ label: "Project", href: "#" }],
    },
    {
      id: "net-sec",
      title: "Computer Network Security",
      where: "University of Mumbai",
      when: "Semester 5",
      color: "from-purple-900 via-fuchsia-700 to-rose-700",
      summary: "Security models for networks: crypto, TLS/SSL, PKI, firewalling.",
      tags: ["Cryptography", "TLS/SSL", "PKI", "Firewalls", "IDS/IPS", "VPN"],
      links: [{ label: "Lab", href: "#" }],
    },
    {
      id: "se",
      title: "Software Engineering",
      where: "University of Mumbai",
      when: "Semester 5",
      color: "from-lime-900 via-lime-700 to-green-700",
      summary: "Requirements to release: patterns, testing, CI/CD, team workflows.",
      tags: ["SDLC", "Requirements", "UML", "Design Patterns", "Testing", "CI/CD", "Agile/Scrum", "Git"],
      links: [{ label: "Case Study", href: "#" }],
    },
    {
      id: "ads",
      title: "Advance Data Structure and Analysis",
      where: "University of Mumbai",
      when: "Semester 5",
      color: "from-amber-900 via-orange-800 to-red-700",
      summary: "Advanced structures and algorithms; performance & proofs.",
      tags: ["Heaps", "Tries", "Segment Trees", "Balanced BST", "Union–Find", "Amortized Analysis"],
      links: [{ label: "Notes", href: "#" }],
    },
    {
      id: "dm-bi",
      title: "Data Mining & Business Intelligence",
      where: "University of Mumbai",
      when: "Semester 6",
      color: "from-cyan-900 via-teal-700 to-emerald-700",
      summary: "Association rules, clustering, OLAP, dashboards & KPIs.",
      tags: ["Association Rules", "Clustering", "Classification", "OLAP", "ETL", "Dashboards", "KPIs"],
      links: [{ label: "Project", href: "#" }],
    },
    {
      id: "webx",
      title: "Web X.0",
      where: "University of Mumbai",
      when: "Semester 6",
      color: "from-indigo-900 via-blue-800 to-sky-700",
      summary: "Modern web paradigms, PWAs, APIs, real-time features.",
      tags: ["PWA", "SPA", "APIs", "Service Workers", "WebSockets", "Responsive"],
      links: [{ label: "Project", href: "#" }],
    },
    {
      id: "wireless",
      title: "Wireless Technology",
      where: "University of Mumbai",
      when: "Semester 6",
      color: "from-fuchsia-900 via-purple-800 to-violet-700",
      summary: "Cellular/Wi-Fi stacks, mobility, spectrum, and QoS.",
      tags: ["Wi-Fi", "Cellular", "Mobility", "Handoff", "Spectrum", "QoS", "Bluetooth"],
      links: [{ label: "Notes", href: "#" }],
    },
    {
      id: "ai-ds",
      title: "AI And DS",
      where: "University of Mumbai",
      when: "Semester 6",
      color: "from-rose-900 via-pink-800 to-fuchsia-700",
      summary: "Machine learning foundations, data processing, model evaluation.",
      tags: ["Supervised", "Unsupervised", "Feature Eng", "Pipelines", "Cross-Validation", "Metrics"],
      links: [{ label: "Lab", href: "#" }],
    },
    {
      id: "img-proc",
      title: "Image Processing",
      where: "University of Mumbai",
      when: "Semester 6",
      color: "from-emerald-900 via-teal-800 to-cyan-700",
      summary: "Filtering, edges, transforms, segmentation, recognition basics.",
      tags: ["Convolution", "Filtering", "Edge Detection", "Fourier", "Segmentation", "Feature Extraction"],
      links: [{ label: "Project", href: "#" }],
    },
    {
      id: "ir",
      title: "Information Retrieval System",
      where: "University of Mumbai",
      when: "Semester 7",
      color: "from-yellow-900 via-amber-800 to-orange-700",
      summary: "Indexing, ranking, vector models, and evaluation (MAP/NDCG).",
      tags: ["Tokenization", "Indexing", "BM25", "Vector Space", "MAP", "NDCG", "Crawling"],
      links: [{ label: "Project", href: "#" }],
    },
    {
      id: "ioe",
      title: "Internet of Everything",
      where: "University of Mumbai",
      when: "Semester 7",
      color: "from-sky-900 via-cyan-800 to-teal-700",
      summary: "IoT/IoE platforms, sensor networks, data ingestion & security.",
      tags: ["IoT", "Sensors", "MQTT", "Edge", "Cloud", "Security"],
      links: [{ label: "Lab", href: "#" }],
    },
    {
      id: "cyber-laws",
      title: "Cyber Security and Laws",
      where: "University of Mumbai",
      when: "Semester 7",
      color: "from-red-900 via-rose-800 to-pink-700",
      summary: "Legal frameworks for security, privacy, and cybercrime.",
      tags: ["Compliance", "Privacy", "IP", "Governance", "Regulations", "Policy"],
      links: [{ label: "Case Brief", href: "#" }],
    },
    {
      id: "infra-sec",
      title: "Infrastructure Security",
      where: "University of Mumbai",
      when: "Semester 7",
      color: "from-emerald-900 via-green-800 to-lime-700",
      summary: "Hardening networks, hosts, and cloud; monitoring and response.",
      tags: ["Hardening", "IAM", "Monitoring", "SIEM", "Incident Response", "Cloud Security"],
      links: [{ label: "Lab", href: "#" }],
    },
    {
      id: "blockchain",
      title: "Blockchain and DLT",
      where: "University of Mumbai",
      when: "Semester 8",
      color: "from-purple-900 via-violet-800 to-indigo-700",
      summary: "Consensus, smart contracts, tokens, and security considerations.",
      tags: ["Ethereum", "Solidity", "Consensus", "Smart Contracts", "Web3", "Crypto"],
      links: [{ label: "Lab", href: "#" }],
    },
    {
      id: "bda",
      title: "Big Data Analytics",
      where: "University of Mumbai",
      when: "Semester 8",
      color: "from-teal-900 via-emerald-800 to-green-700",
      summary: "Batch/stream processing, distributed storage, analytics stacks.",
      tags: ["Hadoop", "Spark", "MapReduce", "Kafka", "Streaming", "HDFS"],
      links: [{ label: "Project", href: "#" }],
    },
    {
      id: "uid",
      title: "User Interface Design",
      where: "University of Mumbai",
      when: "Semester 8",
      color: "from-pink-900 via-rose-800 to-red-700",
      summary: "Interaction design, accessibility, prototyping, and usability tests.",
      tags: ["UX", "UI", "Accessibility", "Prototyping", "Usability", "Figma"],
      links: [{ label: "Case Study", href: "#" }],
    },
    {
      id: "sad-secapp",
      title: "Secure Application Development",
      where: "University of Mumbai",
      when: "Semester 8",
      color: "from-indigo-900 via-blue-800 to-sky-700",
      summary: "Threat modeling, secure coding, testing, and hardening.",
      tags: ["OWASP", "Secure Coding", "Threat Modeling", "Static Analysis", "Pen Testing", "Secrets Mgmt"],
      links: [{ label: "Lab", href: "#" }],
    },
    {
      id: "majors",
      title: "Major Project",
      where: "University of Mumbai",
      when: "Semester 7-8",
      color: "from-stone-900 via-neutral-800 to-slate-700",
      summary: "Fake Signature Detection System: ML-based forgery detection using CNN & VGG16.",
      tags: ["CNN", "VGG16", "Computer Vision", "Classification", "OpenCV", "Python"],
      links: [{ label: "Repo", href: "#" }],
    },
  ];



  return (
    <div className="min-h-screen bg-neutral-950 text-white">
      {/* keep space for your fixed navbar */}
      <div className="pt-16" />

      {/* ===== HERO (Netflix-style banner) ===== */}
      <section className="mx-auto max-w-6xl px-4">
        <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-red-700 via-red-600 to-rose-500">
          {/* subtle lighting + readability */}
          <div className="absolute inset-0 bg-[radial-gradient(1200px_600px_at_-10%_-20%,rgba(255,255,255,0.25),transparent_60%)]" />
          <div className="absolute inset-0 bg-black/35 backdrop-blur-[2px]" />
          <div className="relative p-6 sm:p-8">
            <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs ring-1 ring-white/15">
              <GraduationCap size={14} />
              <span>Education</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold">Education Timeline</h1>
            <p className="text-white/85 max-w-2xl">
              Highlights, coursework, and achievements : All presented like a Netflix hub.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <StatChip Icon={Award} label="Dean’s List x0" />
              <StatChip Icon={Trophy} label="0 Hackathon Wins" />
              <StatChip Icon={BookOpen} label="4 Publications" />
            </div>
          </div>
        </div>
      </section>

      {/* ===== TIMELINE (animates in) ===== */}
      <section className="mx-auto max-w-6xl px-4 py-8">
        <Timeline />
      </section>

      {/* ===== ROWS (horizontal carousels) ===== */}
      <section id="grad-courses" className="mx-auto max-w-6xl px-4 pb-10 space-y-10 scroll-mt-24">
        <CourseRow title="Graduate Coursework (Virginia Tech)" items={MS_COURSES} onOpen={setActive} />
      </section>
      <section id="ug-courses" className="mx-auto max-w-6xl px-4 pb-10 space-y-10 mt-10 scroll-mt-24">
        <CourseRow title="Undergraduate Coursework (University of Mumbai)" items={UG_COURSES} onOpen={setActive} />
        <ClubsAndAwards />
      </section>

      {/* ===== MODAL (More Info) ===== */}
      <CourseModal item={active} onClose={() => setActive(null)} />

      {/* back link */}
      <div className="mx-auto max-w-6xl px-4 pb-10">
        <a
          href="#/"
          onClick={(e) => {
            e.preventDefault();
            if (window.location.hash !== "#/") window.location.hash = "#/";
            setRoute("#/"); 
          }}
          className="text-sm !text-red-600 underline hover:text-white"
        >
          ← Back to Home
        </a>
      </div>
    </div>
  );
}

/* ---------------- small pieces used above ---------------- */

function StatChip({ Icon, label }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-white/10 px-2 py-1 text-xs text-white/85 ring-1 ring-white/15">
      <Icon size={14} />
      {label}
    </span>
  );
}

function Timeline() {
  const [openId, setOpenId] = useState(null);

  const items = [
    {
      id: "vt",
      year: "2024–2026",
      title: "M.S. in Computer Science",
      where: "Virginia Tech, VA",
      points: [
        "Main Focus: Data Science & Artificial Intelligence",
        "Other concentrations: Software Engineering, Computer Security",
        "Projects: Forgery Detection, Intent Classifier",
      ],
      jumpTo: "#grad-courses",
    },
    {
      id: "um",
      year: "2020–2024",
      title: "B.Tech in Computer Science",
      where: "University of Mumbai, India",
      points: [
        "Hackathons & Tech clubs",
        "Capstone: Fake Signature Detection System",
      ],
      jumpTo: "#ug-courses",
    },
  ];

  return (
    <section className="relative">
      {/* glowing center spine (on desktop) */}
      <div className="pointer-events-none absolute left-3 top-0 bottom-0 w-px bg-gradient-to-b from-red-500/60 via-white/20 to-red-500/60 sm:left-1/2" />

      <ol className="space-y-8 sm:space-y-20">
        {items.map((it, i) => {
          const leftSide = i % 2 === 0; // alternate on desktop
          const isOpen = openId === it.id;

          return (
            <motion.li  layout key={it.id} className="relative sm:grid sm:grid-cols-2 sm:gap-10">
              {/* spine dot */}
              <span className="hidden sm:block absolute left-1/2 top-20 -translate-x-1/2 h-3.5 w-3.5 rounded-full bg-white/40 ring-4 ring-neutral-950" />

              <motion.div
                initial={{ y: 10, opacity: 0, scale: 0.98 }}
                whileInView={{ y: 0, opacity: 1, scale: 1 }}
                viewport={{ once: true, amount: 0.35 }}
                transition={{ duration: 0.35 }}
                className={`relative ml-8 !w-85 !h-45 sm:ml-0 max-w-xl rounded-2xl border border-white/10 bg-neutral-900/60 p-4 shadow-lg backdrop-blur-sm
            ${leftSide
                    ? "sm:col-start-1 sm:justify-self-end"
                    : "sm:col-start-2 sm:justify-self-start"}`}
              >
                {/* chips */}
<div className="mb-1 flex flex-wrap items-center gap-2 text-xs text-white/80">
  <span className="inline-flex items-center gap-1 rounded-full bg-white/10 !text-red-400 px-2 py-0.5 ring-1 ring-white/15">
    <GraduationCap size={14} /> {it.year}
  </span>
  <span className="inline-flex items-center gap-1 rounded-full !text-red-400 bg-white/10 px-2 py-0.5 ring-1 ring-white/15">
    <MapPin size={14} /> {it.where}
  </span>
</div>

{/* title */}
<h3 className="text-lg font-semibold">{it.title}</h3>

{/* preview line (first point) */}
<p className="mt-1 text-white/85">{it.points[0]}</p>

{/* expandable details */}
<AnimatePresence initial={false}>
  {isOpen && (
    <motion.ul
      initial={{ height: 0, opacity: 0 }}
      animate={{ height: "auto", opacity: 1 }}
      exit={{ height: 0, opacity: 0 }}
      transition={{ duration: 0.25 }}
      className="mt-2 overflow-hidden list-disc pl-5 text-white/85 space-y-1"
    >
      {it.points.slice(1).map((p) => (
        <li key={p}>{p}</li>
      ))}
    </motion.ul>
  )}
</AnimatePresence>

{/* actions */}
<div className="mt-3 flex items-center gap-2">
  <button
    onClick={() => setOpenId(isOpen ? null : it.id)}
    className="inline-flex !w-28 items-center gap-1 rounded-md !bg-white/10 !px-2 !py-1 !text-xs font-semibold text-white/80 ring-1 ring-white/15 hover:bg-white/15"
    aria-expanded={isOpen}
  >
    {isOpen ? (<><ChevronUp size={14} /> Less</>) : (<><ChevronDown size={14} /> More details</>)}
  </button>
  <a
    href={it.jumpTo}
    className="inline-flex items-center gap-1 rounded-md !bg-white/90 px-3 py-1.5 text-xs font-semibold !text-red-600 hover:bg-white"
  >
    <BookOpen size={14} /> See courses
  </a>
</div>

{/* small mobile dot to the left of card */}
<span className="sm:hidden absolute left-[-29px] top-5 h-3.5 w-3.5 rounded-full bg-white/40 ring-4 ring-neutral-950" />

              </motion.div>
            </motion.li>
          );
        })}
      </ol>
    </section>
  );
}


function CourseRow({ title, items, onOpen }) {
  const scroller = useRef(null);
  const scrollBy = (dir) => scroller.current?.scrollBy({ left: dir * 320, behavior: "smooth" });

  return (
    <section>
      <div className="mb-2 flex items-center justify-between px-1">
        <h2 className="text-lg font-semibold">{title}</h2>
        <div className="flex gap-2">
          <button
            aria-label="Scroll left"
            onClick={() => scrollBy(-1)}
            className="h-12 w-12 rounded-full !bg-transparent ring-1 ring-white/15 hover:bg-white/15
             flex items-center justify-center text-white !text-sm"
          >
            <ChevronLeft size={200} />
          </button>
          <button
            aria-label="Scroll right"
            onClick={() => scrollBy(1)}
            className="h-12 w-12 rounded-full !bg-transparent ring-1 ring-white/15 hover:bg-white/15
             flex items-center justify-center text-white !text-sm"
          >
            <ChevronRight size={400} />
          </button>
        </div>
      </div>

      <div ref={scroller} className="no-scrollbar flex snap-x gap-3 overflow-x-auto pb-1">
        {items.map((it) => (
          <button
            key={it.id}
            onClick={() => onOpen(it)}
            className="group relative h-40 w-72 shrink-0 snap-start overflow-hidden rounded-2xl bg-gradient-to-br p-4 text-left ring-1 ring-white/10 hover:ring-white/20"
          >
            <div className={`absolute inset-0 bg-gradient-to-br ${it.color}`} />
            <div className="absolute inset-0 bg-black/40" />
            <div className="relative z-10 sm:-translate-y-3">
              <div className="mb-1 flex items-center gap-2 px-0 py-0 text-xs text-white/80">
                <span className="rounded-full bg-white/10 px-2 py-0.5 ring-1 ring-white/15">{it.when}</span>
                {/* <span className="rounded-full bg-white/10 px-2 py-0.5 ring-1 ring-white/15">{it.where}</span> */}
              </div>
              <div className="line-clamp-2 text-base font-semibold sm:translate-y-1">{it.title}</div>
              <p className="line-clamp-2 text-sm sm:translate-y-1 text-white/85">{it.summary}</p>
            </div>
            {/* hover hint (Netflix-like) */}
            <div className="absolute inset-x-0 bottom-0 z-10 p-3 flex justify-end opacity-0 transition opacity-100 group-hover:opacity-100">
              <span className="inline-flex items-center gap-1 rounded-md bg-transparent px-3 py-0.5 text-xs font-semibold text-white/80 ring-2 ring-white/15 hover:bg-white/10">
                More info
              </span>
            </div>
          </button>
        ))}
      </div>
    </section>
  );
}

function ClubsAndAwards() {
  const items = [
    { id: "hack", title: "Hackathon Winner", summary: "Built a real-time American Sign Language (ASL) Recognition System in 24 hours.", color: "from-cyan-600 via-sky-500 to-blue-500" },
    { id: "pr", title: "PR & Strategy Head", summary: "@ Khayaal \nHosted 8+ events; 120+ attendees.", color: "from-yellow-600 via-amber-500 to-orange-500" },
    { id: "mentor", title: "Mentor", summary: "Mentored juniors in DS/Algos.", color: "from-green-600 via-emerald-500 to-teal-500" },
  ];
  return (
    <section>
      <h2 className="mb-2 px-1 text-lg font-semibold">Extra-Curriculars</h2>
      <div className="no-scrollbar flex snap-x gap-3 overflow-x-auto pb-1">
        {items.map((it) => (
          <div key={it.id} className="relative h-36 w-64 shrink-0 snap-start overflow-hidden rounded-2xl bg-gradient-to-br p-4 ring-1 ring-white/10">
            <div className={`absolute inset-0 bg-gradient-to-br ${it.color}`} />
            <div className="absolute inset-0 bg-black/40" />
            <div className="relative z-10">
              <div className="text-base font-semibold">{it.title}</div>
              <p className="text-sm text-white/85 line-clamp-3 whitespace-pre-line">{it.summary}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function CourseModal({ item, onClose }) {
  if (!item) return null;
  return (
    <AnimatePresence>
      <motion.div
        key="overlay"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      >
        <motion.div
          key="sheet"
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 20, opacity: 0 }}
          transition={{ type: "spring", stiffness: 260, damping: 22 }}
          className="mx-auto mt-24 max-w-3xl rounded-2xl border border-white/10 bg-neutral-900 p-4 shadow-2xl"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="mb-2 flex items-center justify-between">
            <h3 className="text-lg font-bold !text-red-600">{item.title}</h3>
            <button onClick={onClose} className="rounded-md p-1 !bg-transparent text-white/80 hover:bg-white/10 hover:text-white" aria-label="Close">
              <X />
            </button>
          </div>
          <p className="text-white/85 px-0 py-0 sm:-translate-y-2">{item.summary}</p>

          <div className="mt-3 flex flex-wrap gap-2">
            {item.tags?.map((t) => (
              <span key={t} className="rounded-full bg-white/10 px-6 py-0.5 text-xs text-white/80 ring-1 ring-white/15">
                {t}
              </span>
            ))}
          </div>

          {item.links?.length ? (
            <div className="mt-4 flex flex-wrap gap-2 justify-end">
              {item.links.map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  className="inline-flex items-center gap-2 rounded-md bg-white/10 px-5.5 py-2 text-sm font-semibold !text-red-600 ring-2 ring-white/20 hover:bg-white/15"
                >
                  <ExternalLink size={16} /> {l.label}
                </a>
              ))}
            </div>
          ) : null}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
